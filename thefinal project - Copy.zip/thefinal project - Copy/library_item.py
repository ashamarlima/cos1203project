class LibraryItem:
    def __init__(self, name, artist, rating=0):
        self.name = name
        self.artist = artist
        
        # Check if rating is an integer, if not, raise an error
        if not isinstance(rating, int):
            raise TypeError("Rating must be an integer.")
        
        # Optional: You can also enforce a valid range for the rating (e.g., 0-5)
        if rating < 0 or rating > 5:
            raise ValueError("Rating must be between 0 and 5.")
        
        self.rating = rating
        self.play_count = 0

    def info(self):
        return f"{self.name} - {self.artist} {self.stars()}"

    def stars(self):
        stars = ""
        for i in range(self.rating):
            stars += "*"
        return stars
