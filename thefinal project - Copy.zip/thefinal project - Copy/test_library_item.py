import pytest
from library_item import LibraryItem

# Test Initialization
def test_library_item_initialization():
    # Test with default rating
    item = LibraryItem(name="Song 1", artist="Artist 1")
    assert item.name == "Song 1"
    assert item.artist == "Artist 1"
    assert item.rating == 0
    assert item.play_count == 0

    # Test with specific rating
    item2 = LibraryItem(name="Song 2", artist="Artist 2", rating=3)
    assert item2.name == "Song 2"
    assert item2.artist == "Artist 2"
    assert item2.rating == 3
    assert item2.play_count == 0

# Test the info() method
def test_info_method():
    item = LibraryItem(name="Song 1", artist="Artist 1", rating=2)
    expected_info = "Song 1 - Artist 1 **"
    assert item.info() == expected_info

# Test the stars() method
def test_stars_method():
    item = LibraryItem(name="Song 1", artist="Artist 1", rating=3)
    assert item.stars() == "***"  # 3 stars

    item2 = LibraryItem(name="Song 2", artist="Artist 2", rating=0)
    assert item2.stars() == ""  # 0 stars

    item3 = LibraryItem(name="Song 3", artist="Artist 3", rating=5)
    assert item3.stars() == "*****"  # 5 stars

# Test invalid rating
def test_invalid_rating():
    # Test if the rating is set correctly when passed as an integer
    item = LibraryItem(name="Song 4", artist="Artist 4", rating=4)
    assert item.rating == 4
    
    # Test invalid rating input (non-integer)
    with pytest.raises(TypeError):
        item_invalid = LibraryItem(name="Song 5", artist="Artist 5", rating="four")

    # Test if play count is zero after initialization
    item_no_play = LibraryItem(name="Song 6", artist="Artist 6")
    assert item_no_play.play_count == 0
