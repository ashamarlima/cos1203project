import csv
from library_item import LibraryItem

# Initialize an empty library
library = {}

def import_from_csv(file_path="library_data.csv"):
  #import library data from a CSV file.
  try:
    with open(file_path, mode='r', encoding='utf-8') as file:
      reader = csv.DictReader(file)
      for row in reader:
        # Create LibraryItem objects and populate the library dictionary
        key = row["Key"]
        name = row["Name"]
        artist = row["Artist"]
        rating = int(row["Rating"])
        play_count = int(row["Play Count"])

        library[key] = LibraryItem(name, artist, rating)
        library[key].play_count = play_count
  except FileNotFoundError:
    print(f"Error: {file_path} not found.")
  except Exception as e:
    print(f"An error occurred while importing data: {e}")

# Import data from the CSV file at startup
import_from_csv()

# Functions for interacting with the library (same as before)
def list_all():
  output = ""
  for key in library:
    item = library[key]
    output += f"{key} {item.info()}\n"
  return output

def get_name(key):
  try:
    item = library[key]
    return item.name
  except KeyError:
    return None

def get_artist(key):
  try:
    item = library[key]
    return item.artist
  except KeyError:
    return None

def get_rating(key):
  try:
    item = library[key]
    return item.rating
  except KeyError:
    return -1

def set_rating(key, rating):
  try:
    item = library[key]
    item.rating = rating
  except KeyError:
    return

def get_play_count(key):
  try:
    item = library[key]
    return item.play_count
  except KeyError:
    return -1
 
def increment_play_count(key):
  try:
    item = library[key]
    item.play_count += 1
  except KeyError:
    return


# In track_library.py