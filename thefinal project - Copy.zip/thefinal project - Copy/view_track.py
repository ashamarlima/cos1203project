import tkinter as tk
import tkinter.scrolledtext as tkst
import track_library as lib
import font_manager as fonts
from tkinter import messagebox

import tkinter as tk
import tkinter.scrolledtext as tkst
import track_library as lib
import font_manager as fonts
from PIL import Image, ImageTk
from tkinter import messagebox

import tkinter as tk
import tkinter.scrolledtext as tkst
import track_library as lib
import font_manager as fonts
from tkinter import messagebox
from PIL import Image, ImageTk

def set_text(text_area, content):
    """Clear and insert new content into the text area."""
    text_area.delete("1.0", tk.END)
    text_area.insert(1.0, content)

class TrackViewer:
    def __init__(self, window):
        # Set up window properties
        window.geometry("900x500")
        window.title("View Tracks")
        window.config(bg="#2C3E50")  # Dark background color

        # Button to list all tracks
        self.list_tracks_btn = tk.Button(window, text="List All Tracks", command=self.list_tracks_clicked,
                                          bg="#3498DB", fg="white", font=("Helvetica", 12), relief="flat", 
                                          activebackground="#2980B9", activeforeground="white")
        self.list_tracks_btn.grid(row=0, column=0, padx=10, pady=10)

        # Scrolled text widget for listing tracks
        self.list_txt = tkst.ScrolledText(window, width=48, height=12, wrap="none", state="normal", cursor="hand2", 
                                          font=("Helvetica", 12), bg="#34495E", fg="white", insertbackground="white")
        self.list_txt.grid(row=1, column=0, columnspan=3, sticky="W", padx=10, pady=10)
        self.list_txt.bind("<Button-1>", self.track_clicked)  # Bind left-click to list widget

        # Text widget for displaying track details
        self.track_txt = tk.Text(window, width=24, height=4, wrap="none", state="normal", font=("Helvetica", 12),
                                 bg="#34495E", fg="white", insertbackground="white")
        self.track_txt.grid(row=1, column=3, sticky="NW", padx=10, pady=10)

        # Status label
        self.status_lbl = tk.Label(window, text="", font=("Helvetica", 10), bg="#2C3E50", fg="white")
        self.status_lbl.grid(row=2, column=0, columnspan=4, sticky="W", padx=10, pady=10)

        # Playlist display section
        self.playlist_label = tk.Label(window, text="Playlist", font=("Helvetica", 12), bg="#2C3E50", fg="white")
        self.playlist_label.grid(row=0, column=3, padx=10, pady=10)

        self.playlist_txt = tkst.ScrolledText(window, width=24, height=12, wrap="none", state="normal", font=("Helvetica", 12),
                                              bg="#34495E", fg="white", insertbackground="white")
        self.playlist_txt.grid(row=1, column=4, padx=10, pady=10)

        # Playlist list
        self.playlist = []

        # Button to clear the playlist
        self.clear_playlist_btn = tk.Button(window, text="Clear Playlist", command=self.clear_playlist,
                                             bg="#E74C3C", fg="white", font=("Helvetica", 12), relief="flat",
                                             activebackground="#C0392B", activeforeground="white")
        self.clear_playlist_btn.grid(row=2, column=3, padx=10, pady=10)

        # Entry field to input the new rating
        self.rating_entry = tk.Entry(window, width=5, font=("Helvetica", 12), bg="#34495E", fg="white")
        self.rating_entry.grid(row=3, column=0, padx=10, pady=10)

        # Button to update the rating
        self.update_rating_btn = tk.Button(window, text="Update Rating", command=self.update_rating,
                                           bg="#F39C12", fg="white", font=("Helvetica", 12), relief="flat",
                                           activebackground="#E67E22", activeforeground="white")
        self.update_rating_btn.grid(row=3, column=1, padx=10, pady=10)

        # Button to play the playlist
        self.play_playlist_btn = tk.Button(window, text="Play Playlist", command=self.play_playlist,
                                           bg="#2ECC71", fg="white", font=("Helvetica", 12), relief="flat",
                                           activebackground="#27AE60", activeforeground="white")
        self.play_playlist_btn.grid(row=3, column=2, padx=10, pady=10)

        # Label for track image display
        self.image_label = tk.Label(window)
        self.image_label.grid(row=1, column=5, padx=10, pady=10)

        # Populate the track list on startup
        self.list_tracks_clicked()

        # Store the currently selected track ID
        self.current_track_id = None

        # Track the number of times the playlist has been played
        self.play_count = 0  # Initialize play count

    def list_tracks_clicked(self):
        """Display all tracks in the ScrolledText widget."""
        track_list = lib.list_all()
        set_text(self.list_txt, track_list)
        self.status_lbl.configure(text="List Tracks button was clicked!")

    def track_clicked(self, event):
        """Handle clicks on the track list."""
        try:
            # Get the clicked line index
            clicked_line = self.list_txt.index(f"@{event.x},{event.y}").split(".")[0]
            track_line = self.list_txt.get(f"{clicked_line}.0", f"{clicked_line}.end").strip()
            
            # Debug: Print clicked line to see what we got
            print(f"Clicked line: {track_line}")
            
            # Extract the track ID (assuming it's the first part of the line)
            track_id = track_line.split(" ")[0]
            
            # Debug: Print parsed track ID
            print(f"Parsed track_id: {track_id}")

            # Retrieve track details
            name = lib.get_name(track_id)
            
            # Debug: Check if track name was fetched
            if not name:
                raise ValueError(f"No track found with ID {track_id}")
            print(f"Track Name: {name}")
            
            artist = lib.get_artist(track_id)
            rating = lib.get_rating(track_id)
            play_count = lib.get_play_count(track_id)

            # Debug: Print other track details
            print(f"Track Artist: {artist}, Rating: {rating}, Play Count: {play_count}")
            
            # Update the UI with track details
            track_details = f"Playing:\n{name}\n{artist}\nRating: {rating}\nPlays: {play_count}"
            set_text(self.track_txt, track_details)

            # Increment play count
            lib.increment_play_count(track_id)
            print(f"Play count for track {track_id} incremented.")

            # Update the list of tracks to reflect the updated play count
            self.list_tracks_clicked()

            # Update the rating field
            self.rating_entry.delete(0, tk.END)
            self.rating_entry.insert(0, str(rating))

            # Set the current track ID for future use
            self.current_track_id = track_id

            # Add the track to the playlist
            self.add_to_playlist(track_id)

            # Update status label
            self.status_lbl.configure(text=f"Now playing: {name}")

        except ValueError as e:
            self.status_lbl.configure(text=f"Error: {e}")
        except Exception as e:
            self.status_lbl.configure(text=f"Unexpected error: {e}")
            # Print the full error for debugging
            print(f"Unexpected error: {e}")

    def add_to_playlist(self, track_id):
        """Add track to the playlist."""
        name = lib.get_name(track_id)
        if name:
            if track_id not in self.playlist:
                self.playlist.append(track_id)
                self.status_lbl.configure(text=f"Added '{name}' to playlist!")
                self.update_playlist_display()
            else:
                self.status_lbl.configure(text=f"'{name}' is already in the playlist.")

    def remove_from_playlist(self):
        """Remove selected track from the playlist."""
        if not self.playlist:
            self.status_lbl.configure(text="Playlist is empty. No track to remove.")
            return
        track_id = self.rating_entry.get()
        if track_id in self.playlist:
            self.playlist.remove(track_id)
            self.status_lbl.configure(text=f"Removed track {track_id} from playlist.")
            self.update_playlist_display()
        else:
            self.status_lbl.configure(text="Track not found in playlist.")

    def update_rating(self):
        """Update the rating of the selected track."""
        if not self.current_track_id:
            self.status_lbl.configure(text="Please select a track first.")
            return
        new_rating = self.rating_entry.get()
        try:
            new_rating = int(new_rating)
            if 1 <= new_rating <= 5:
                lib.set_rating(self.current_track_id, new_rating)
                self.status_lbl.configure(text=f"Rating for track {self.current_track_id} updated to {new_rating}")
                self.list_tracks_clicked()
            else:
                self.status_lbl.configure(text="Rating must be between 1 and 5.")
        except ValueError:
            self.status_lbl.configure(text="Please enter a valid rating between 1 and 5.")

    def clear_playlist(self):
        """Clear all songs from the playlist."""
        self.playlist.clear()
        self.status_lbl.configure(text="Playlist has been cleared.")
        self.update_playlist_display()

    def update_playlist_display(self):
        """Update the display of the playlist."""
        if not self.playlist:
            set_text(self.playlist_txt, "No tracks in playlist.")
        else:
            playlist_text = "\n".join(lib.get_name(track_id) for track_id in self.playlist)
            set_text(self.playlist_txt, playlist_text)

    def play_playlist(self):
        """Play the tracks in the playlist and count how many times the playlist has been played."""
        if not self.playlist:
            self.status_lbl.configure(text="No tracks in the playlist to play.")
            return

        # Increment play count each time the playlist is played
        self.play_count += 1
        
        # Display the number of times the playlist has been played
        self.status_lbl.configure(text=f"Playing playlist... This playlist has been played {self.play_count} times.")
        
        # Placeholder for playing the tracks from the playlist
        for track_id in self.playlist:
            print(f"Playing: {lib.get_name(track_id)}")

# Create main window
root = tk.Tk()
app = TrackViewer(root)

# Start the GUI event loop
root.mainloop()


if __name__ == "__main__":
    window = tk.Tk()
    fonts.configure()
    TrackViewer(window)
    window.mainloop()
